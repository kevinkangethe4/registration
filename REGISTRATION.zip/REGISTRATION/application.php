<?php
include('session.php');
//if (isset($_POST['upload'])){
	//$file_name = $_FILES['file']['name'];
	//$file_type = $_FILES['file']['type'];
	//$file_size = $_FILES['file']['size'];
	//$file_tem_Loc = $_FILES['file']['tmp_name'];
	//$file_store = "upload/".$file_name;
	//IF (move_uploaded_file($file_tem_Loc,$file_store)){
	//ECHO "Resume Uploaded. Thank you!!";
//}

//}

?>
<!doctype html>
<html>
<head><h1 style = text-align:center;>Application Form</h1><head>
<title>Application Form</title>
<table width="1000">
<tr>
<td>
<H1 STYLE = background-color:white;color:green;font-size:20px; >Hey <?php echo $login_session; ?> please fill this form to proceed with your applications.........</td><td><a href = "logout.php" style = width:5%; text-align:right;color:white; font-family:bold; font-size:50px;>Sign Out</a></H1>
</td></tr>
</table>
<link rel="stylesheet" href="app.css">
<div class="login-box">

<table width="1000" height="15">
<form  action="appf.php"  method="POST" enctype="multipart/form-data">	
<tr><td><input type="text" placeholder= "JOB REF NO" id="refno" name="refno"></td></tr>
<tr><td><input type="text" placeholder= "First Name" id="firstname" name="firstname"></td></tr>
<tr><td><input type="text" placeholder= "Last Name" id="lastname" name="lastname"></td></tr>
<tr><td><h2> Date Of Birth</h2></td></tr>
<tr><td><input type="date" placeholder= "Date Of Birth" id="dob" name="dob"></td></tr>
<tr><td><h2> Gender</h2></td></tr>
<tr><td><input type="radio" name="gender" value="male">Male<br><input type ="radio" name="gender" value="female">Female
<br><input type ="radio" name="gender" value="others">Others
<tr><td><input type="email" placeholder= "Email" id="email" name="email"></td></tr>
<tr><td><input type="text" placeholder= "Phone Number" id="phone" name="phone"></td></tr>
<tr><td><input type="text" placeholder= "Resident" id="resident" name="resident"></td></tr>
<tr><td><input type="text" placeholder= "Salary Expected" id="salary" name="salary"></td></tr>
<tr><td><h2>Your Highest Acadamic Level  </h2></td></tr>
<tr><td><input type="radio" name="edu" value="PHD">PHD<br><input type ="radio" name="edu" value="MASTER'S">MASTER'S
<br><input type ="radio" name="edu" value="UNDER GRADUATE">UNDER GRADUATE <br><input type ="radio" name="edu" value="ADVANCE DIPLOMA">ADVANCE DIPLOMA
<br><input type ="radio" name="edu" value="DIPLOMA">DIPLOMA
<br><input type ="radio" name="edu" value="Craft">Craft <br><input type ="radio" name="edu" value="High SCHOOL">High SCHOOL
<tr><td><input type="text" placeholder= "Name of Institution you Attended" id="ins" name="ins"></td></tr>
<tr><td><input type="text" placeholder= "Course" id="course" name="course"></td></tr>
<tr><td><h2>Year of Graduation  </h2></td></tr>
<tr><td><input type="month" style = background-color:white;color:red;font-family:bold;font-size:20px;width:58%;padding:10px 30px;margin:10px 0;border:1px solid;border-color:red;border-radius:4px; box-sizing:border-box;display:inline-block;border-bottom:2px solid red; placeholder= "Year of graduation" id="year" name="year"></td></tr>
<tr><td><input type="text" placeholder= "Grade awarded" id="ga" name="ga"></td></tr>
<tr><td><textarea  name="cl"  placeholder="Cover letter"></textarea></td></tr>

<tr><td><h2><input type="submit" value="Submit and Proceed"></h2></td> </td></tr>
</table>
</form>
</div>
</body>
</html>