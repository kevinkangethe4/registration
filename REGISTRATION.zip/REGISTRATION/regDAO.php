<?php

require_once 'dbconfig.php';
 
class Candidate
{	

	private $conn;
	 
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db; 
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql); 
		return $stmt;
	}
	
	public function lasdID()
	{
		$stmt = $this->conn->lastInsertId();
		$stmt=null;
	    //$this->conn=null;	
		return $stmt;
	}
	
	public function insertCandidate($email,$password,$idnumber,$firstname,$lastname,$phone,$resident,$dateofbirth,$gender)
	{
		try
		{							 
			$stmt = $this->conn->prepare("INSERT INTO tblreg($email,$password,$idnumber,$firstname,$lastname,$phone,$resident,$dateofbirth,$gender)  VALUES(?,?,?,?,?,?,?,?,?)");
			  
			$stmt->execute(array($email,$password,$idnumber,$firstname,$lastname,$phone,$resident,$dateofbirth,$gender)); 	
			return $stmt;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
		}
	}
	
	
	
	   
	
	   
	
	public function selectCandidateByEmail($email)
	{
		try
		{							  
			$stmt = $this->conn->prepare("SELECT * FROM tblreg WHERE email=?");
			$stmt->execute(array($email));
			$rows=$stmt->fetch(PDO::FETCH_ASSOC);
			 	
			$stmt=null;
			//$this->conn=null;	
			return $rows; 
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
		}
	}
	 
	public function login($email,$password)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT * FROM tblreg WHERE email=?");
			$stmt->execute(array($email));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
			
			if($stmt->rowCount() == 1)
			{ 
					if($userRow['password']==$password)
					{
						$_SESSION['userSession'] = $userRow['candidateId'];
						return true;
					}
					else
					{
						header("Location: login.php?error");
						exit;
					}  	
			}
			else
			{
				header("Location: login.php?error");
				exit;
			}	
			$stmt=null;
			$this->conn=null;	
				
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
		}
	}
	 
}