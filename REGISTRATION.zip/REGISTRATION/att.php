<?php
include ('session.php');
if (isset($_FILES['file_array'])){
	$name_array = $_FILES['file_array']['name'];
    $tmp_name_array = $_FILES['file_array']['tmp_name'];
    $type_array = $_FILES['file_array']['type'];
	$size_array = $_FILES['file_array']['size'];
	$error_array = $_FILES['file_array']['error'];
	for($i = 0; $i < count($tmp_name_array); $i++){
		if (move_uploaded_file($tmp_name_array[$i], "upload/".$name_array[$i])){
			echo $name_array[$i] ."upload complate<br>";
		}else{
		echo "move_uploaded_file function failed for ".$name_array[$i]."<br>";
		}
		
	}
}
?>
<!doctype html>
<html>
<title>login tab</title>
<link rel="stylesheet" href="att.css">
<body>

<table>
<tr>
<td>
<H1 STYLE = background-color:white;color:green;font-size:20px; >Thanks  <?php echo $login_session; ?>  For filling the applications form,As we looks forward.........</td><td><a href = "logout.php" style = width:5%; text-align:right;color:white; font-family:bold; font-size:50px;>Sign Out</a></H1>

</tr>
</td>
</table>
</body>
</html>