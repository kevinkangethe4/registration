<?php
include('session.php');
?>
<!doctype html>
<html>
<head><h2 style = background-color:green;color:red;>ICT Jobs  </h2></head>
<title>ICT Jobs</title>
<link rel="stylesheet" href="home.css">
<body>
<table width="1000">
<tr>

<td><h1 style =  background-color:white;color:green;text-align:left; >Welcome <?php echo $login_session; ?> thanks <br>for visting our site..........</h1> </td>
     <td> <h2 style=font-size:15px; background-color:blue;><a href = "logout.php" style = color:white; font-family:bold; font-size:50px;>Sign Out</a></h2></td>
	 </tr>
<tr><td><h2 style= background-color:green; ><a href="icto.php" style = color:red;>ICT Officer-ref:ict/12</a></h2></td></tr>
<tr><td><h2 style= background-color:lightgrey;text-align:left;font-size:20px;><ul><li>Diploma or Degree in I.T or related</li>
<li>5 years working exeperience</li>
<li>CCNA certification</li>
<li>Knowledge on web design </li>
<li>experince in SQL databases</li>
<li><a href="icto.php" style = color:red;>Read more</a></li></h2>
</ul>
</td>

</tr>
<tr><td><h2 style= background-color:green; ><a href="sd.php" style = color:red;>Software Developer-ref:ict/13</a> </h2></td></tr>
<tr><td><h2 style= background-color:lightgrey;text-align:left;font-size:20px;><ul><li>BSC degree in I.T or related</li>
<li>5 years working exeperience</li>
<li>Knowledge on C# ,JAVA , PYTHONE OR all</li>
<li>Knowledge on FRONT END SOFTWARE development </li>
<li>experince in SQL,mysql and MSACCESS databases</li>
<li>knowledge on HTML,CSS,JAVA script and PHP
<li><a href="sd.php" style = color:red;;>Read more</a></li></h2>
</ul>
</td>

</tr>
<tr><td><h2 style= background-color:green; ><a href="itm.php" style = color:red; >IT MANAGER-ref:ict/14</a></h2></td></tr>
<tr><td><h2 style = background-color:lightgrey;text-align:left;font-size:20px;><ul><li>BSC degree in I.T or related</li>
<li>Over 10 years working exeperience ,2 Years in Management level </li>
<li>Knowledge on C# ,JAVA , PYTHONE OR all</li>
<li>Knowledge on FRONT END SOFTWARE development </li>
<li>experince in SQL,mysql and MSACCESS databases</li>
<li>knowledge on HTML,CSS,JAVA script and PHP</li>
<li>PEARL CERTFICATION</li>
<li>post graduate degree in project managements will be an added advantage</li>
<li><a href="itm.php"style = color:red;>Read more</a></li></h2>
</ul>
</td>

</tr>
</table>
<html>