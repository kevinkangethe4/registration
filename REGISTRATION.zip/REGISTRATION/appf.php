<?php
$refno=$_POST['refno'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$dob=$_POST['dob'];
$gender=$_POST['gender'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$resident=$_POST['resident'];
$salary=$_POST['salary'];
$edu=$_POST['edu'];
$ins=$_POST['ins'];
$course=$_POST['course'];
$year=$_POST['year'];
$ga=$_POST['ga'];
$cl=$_POST['cl'];

$conn = new mysqli('localhost','root','','registation');
if($conn->connect_error){
	die('connection Failed : '.$conn->connect_error);
}else{
    $stmt = $conn->prepare("insert into tblapp(refno,firstname,lastname,dob,gender,email,phone,resident,salary,edu,ins,course,year,ga,cl)
	values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	$stmt->bind_param("ssssssissssssss",$refno,$firstname,$lastname,$dob,$gender,$email,$phone,$resident,$salary,$edu,$ins,$course,$year,$ga,$cl);
	$stmt->execute();
	echo"Application succefully Submmited..........";
	$stmt->close();
	$conn->close();
}

	
?>
<doctype html>
<html>

<title>attachment</title>
<link rel="stylesheet" href="att.css">
<div class="login-box">
<form  action="att.php"  method="POST" enctype="multipart/form-data">	
<body>
<div class="login-box">
<h2 style=font-size:20px;text-align:center;>Application Form</h1>
<table width="200" height="15">
<tr><td>Select to Upload Resume    :<input type="file" name="file_array[]"/></td></tr><p>

<tr><td> Upload recent Certificate :<input type="file" name="file_array[]"/></td></tr><p>

<tr><td> Upload ID's Or Passport's :<input type="file" name="file_array[]"/></td>
<td><input type ="submit" style=width:100%; value="Upload Documents" name="uploa"></td></tr>
</table>
</body>
</html>