<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $email = mysqli_real_escape_string($db,$_POST['email']);
      $password = mysqli_real_escape_string($db,$_POST['password']); 
	  //$firstname = mysqli_real_escape_string($db,$_POST['firstname']);
      
      $sql = "SELECT idnumber FROM tblreg WHERE email = '$email' and password = '$password' ";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         //session_register("firstname");
         $_SESSION['login_user'] = $email;
         
         header("location: home.php");
      }else {
          echo "Wrong Password or Username.Please try again";
      }
   }
?>

<doctype html>
<html>
<title>Login Form</title>
<link rel="stylesheet" href="login.css">
<body>
<div class="login-box">
<h1>login</h1>
<form action="" method="POST">

<div class="textbox">
<input type="email" id="email" placeholder="email address" name="email" required /><br/>
</div>
<div class="textbox">
<input type="password" id="password" placeholder="password" name="password" required /><br/>
</div>
<p style= text-align:center;><input type="submit"  value="LOGIN"></p>
<h2 style=font-size:20px;>Not Registered? Please<a href="reg.php">Sign Up</a> here</h2>
</body>
</form>
</html>
