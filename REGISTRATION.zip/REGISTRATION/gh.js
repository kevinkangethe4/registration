function compare_valid(password, repassword) { 

     fld_val = document.getElementById(password).value; 

    fld2_val = document.getElementById(repassword).value; 

     if (fld_val == fld2_val) { 

        update_css_class(repassword, 2); 

         p_valid_r = 1; 

     } else { 

        update_css_class(repassword, 1); 

       p_valid_r = 0; 

     } 
    return p_valid_r; 

} 
