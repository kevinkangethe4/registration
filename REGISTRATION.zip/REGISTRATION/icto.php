 <?php
include('session.php');
?>
 <!doctype html>
<html>
<head><h1 style=background-color:green; >ICT Officer REF:ICT/12</H1></head>
<title>ICT officer</title>
<link rel="stylesheet" href="home.css">
<table width="1000">
<td><h1 style =  background-color:white;color:green; >Welcome <?php echo $login_session; ?> thanks <br>for visting our site..........</h1> </td>
     <td> <h2 style=font-size:15px; background-color:blue;><a href = "logout.php" style = color:green; font-family:bold; font-size:50px;>Sign Out</a></h2></td>
	 </tr>
<tr>
<td><h1 style = background-color:green; ><u>Responsibilities/Roles</u></h1></tr>
<tr><td><h2 style = background-color:lightgrey;text-align:left;font-size:20px;color:green;>
<uL><li>Trouble shooting Networking bugs</li>
<li>hardware and software support and Maintance</li>
<li>software upgrade</li>
<li>configuration of mails</li>
<li>heading the preventive maintances tasks</li></h2>
</ul>
</td>
</tr>
<tr><td><h1 style=background-color:green;><u>Qualifications</u></h1></td></tr>
<tr><td>
<h2 style = background-color:lightgrey;text-align:left;font-size:20px;><ul><li>Diploma In I.T or related</li>
<li>CCNA Certifications</li>
<li>Atleast 3 year working exepirence</li>
<li>over 28 years  </li></h2>
</ul>
</td>
</tr>
<tr><td><h2 style=font-size:20px;background-color:red;><a href="application.php" style = color:green;>Apply here</a></h2></td></tr>
</table>