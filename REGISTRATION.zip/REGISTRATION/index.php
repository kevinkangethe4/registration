<?php  
header("Location: login.php");
   
?>

<!DOCTYPE html>
<html>
  <head>
    
  </head>
  <body>
  	
  </body>
</html>