<?php 
if (isset($_FILES['file_array'])){
	$name_array = $_FILES['file_array']['name'];
    $tmp_name_array = $_FILES['file_array']['tmp_name'];
    $type_array = $_FILES['file_array']['type'];
	$size_array = $_FILES['file_array']['size'];
	$error_array = $_FILES['file_array']['error'];
	for($i = 0; $i < count($tmp_name_array); $i++){
		if (move_uploaded_file($tmp_name_array[$i], "upload/".$name_array[$i])){
			echo $name_array[$i] ."upload complate<br>";
		}else{
		echo "move_uploaded_file function failed for ".$name_array[$i]."<br>";
		}
		
	}
}
?>