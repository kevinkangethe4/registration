<?php
$email=$_POST['email'];
$password=$_POST['password'];
$idnumber=$_POST['idnumber'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$phone=$_POST['phone'];
$resident=$_POST['resident'];
$dateofbirth=$_POST['dateofbirth'];
$gender=$_POST['gender'];
$conn = new mysqli('localhost','root','','registation');
if($conn->connect_error){
	die('connection Failed : '.$conn->connect_error);
}else{
    $stmt = $conn->prepare("insert into tblreg(email,password,idnumber,firstname,lastname,phone,resident,dateofbirth,gender)
	values(?,?,?,?,?,?,?,?,?)");
	$stmt->bind_param("ssississs",$email,$password,$idnumber,$firstname,$lastname,$phone,$resident,$dateofbirth,$gender);
	$stmt->execute();
	echo"registrated succefully..........";
	$stmt->close();
	$conn->close();
}

	
?>
<doctype html>
<html>
<style>
a:link,.vistited{color:white; background-color:red; font-size:20px;width:100%;margin:8px;border:1px solid;padding:12px 20px;}
</style>
<link rel="stylesheet" href="login.css">
<body>
<div class="login-box">
<table>
<tr>
<td>
<h2 style=font-size:30;text-align:left;>Please login here<a href="login.php">Login</a> to Proceed</h2>
</tr>
</td>
</table>
</body>
</html>