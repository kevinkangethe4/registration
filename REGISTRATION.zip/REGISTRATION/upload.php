<?php

 $targetfolder = "testupload/";

 $targetfolder = $targetfolder . basename( $_FILES['pdfFile']['name']) ;

if(move_uploaded_file($_FILES['pdfFile']['tmp_name'], $targetfolder))

 {

 echo "The file ". basename( $_FILES['pdfFile']['name']). " is uploaded";

 }

 else {

 echo "Problem uploading file";

 }

 ?>


<?php

 $targetfolder = "testupload/";

 $targetfolder = $targetfolder . basename( $_FILES['pdfFile']['name']) ;

 $ok=1;

$file_type=$_FILES['pdfFile']['type'];

if ($file_type=="application/pdf" || $file_type=="image/gif" || $file_type=="image/jpeg") {

 if(move_uploaded_file($_FILES['pdfFile']['tmp_name'], $targetfolder))

 {

 echo "The file ". basename( $_FILES['pdfFile']['name']). " is uploaded";

 }

 else {

 echo "Problem uploading file";

 }

}

else {

 echo "You may only upload PDFs, JPEGs or GIF files.<br>";

}

?>

