<?php
include('session.php');
?>
<!doctype html>
<html>
<title>home</title>
<link rel="stylesheet" href="home.css">
<body>

<table width="1000">
<tr>
<td><h1 style =  background-color:white;color:green; >Welcome <?php echo $login_session; ?> thanks <br>for visting our site..........</h1> </td>
     <td> <h2 style=font-size:15px; background-color:blue;><a href = "logout.php" style = color:white; font-family:bold; font-size:50px;>Sign Out</a></h2></td>
	 </tr>
	 <TR><TD><H2 style=background-color:green;color:red;> Select the following career's Opportunities</h2></td></tr>
	 <tr><td><h2><select style = background-color:white;font-size:30px;font-family:bold;name="select" placeholder="Please Select Here" onchange="location = this.value;"> 

           <option  value="ict.php">SELECT</option> 
		   
           <option  value="ict.php">ICT Jobs</option> 
           <option value="oa.php">O.A Jobs</option> 
		   <option value="oa.php">Accounts Jobs</option> 
		   <option value="oa.php">Teaching Jobs </option> 
		   <option value="oa.php">Logistics Jobs </option>

</select>

</table>
</html>