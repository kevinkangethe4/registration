<?php
include('session.php');
?>
<!doctype html>
<html>
<head><h1 style=background-color:green;>SYSTEM'S DEVELOPER REF:ICT/13</H1></head>
<title>Systems Developer</title>
<link rel="stylesheet" href="home.css">
<table width="1000">
<td><h1 style =  background-color:white;color:green; >Welcome <?php echo $login_session; ?> thanks <br>for visting our site..........</h1> </td>
     <td> <h2 style=font-size:15px; background-color:blue;><a href = "logout.php" style = color:green; font-family:bold; font-size:50px;>Sign Out</a></h2></td>
	 </tr>
<tr>
<td><h1 style=background-color:green;><u>Responsibilities/Roles</u></h1></tr>
<tr><td><h2 style=text-align:left;font-size:20px;background-color:lightgrey;>
<uL><li>Developing new Systems Applications</li>
<li> Maintance of the existings Systems</li>
<li> upgrade of existing systems</li>
<li>web development</li>
<li>using SDLC </li></h2>
</ul>
</td>
</tr>
<tr><td><h1 style=background-color:green;><u>Qualifications</u></h1></td></tr>
<tr><td>
<h2 style=text-align:left;font-size:20px;background-color:lightgrey;><ul><li>BSC OF SCIENCE In I.T or related</li>
<li>Knowledge of SDLC stages</li>
<li>Atleast 5 year working exepirence</li>
<li>over 28 years  </li>
<li>Knowledge on C# ,JAVA , PYTHONE OR all</li>
<li>Knowledge on FRONT END SOFTWARE development</li>
<li>experince in SQL,mysql and MSACCESS databases</li>
<li>knowledge on HTML,CSS,JAVA script and PHP </li>
</h2>
</ul>
</td>
</tr>
<tr><td><h2 style=font-size:20px;background-color:red;><a href="application.php" style = color:green; >Apply here</a></h2></td></tr>
</table>