<?php

if (isset($_POST['upload'])){
$file_name = $_FILES['file']['name'];
$file_type = $_FILES['file']['type'];
$file_size = $_FILES['file']['size'];
$file_tem_Loc = $_FILES['file']['temp_name'];
$file_store = "uploads/".$file_name;
IF (move_uploaded_file($file_tem_Loc,$file_store)){
	ECHO "FILE ARE UPLOADED";
}

}
?>