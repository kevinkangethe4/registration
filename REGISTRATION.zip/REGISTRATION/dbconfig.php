<?php
class Database
{
     
    private $host;
    private $db_name;
    private $username; 
    private $password;
    private $port; 
    public $conn;
    
    public function __construct(){

        $this->host = "localhost";
        $this->db_name = "registation";
        $this->username = "root";
        $this->password = "";
        $this->port = "3306"; 
    }

    public function dbConnection()
	{
     
	    $this->conn = null;    
        try
		{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
			//$this->conn = new PDO("dblib:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password, array(PDO::ATTR_PERSISTENT=>false));
            //$this->conn = new PDO ("dblib:host=$this->host:$this->port;dbname=$this->db_name", "$this->username", "$this->password");
            //$this->db = new PDO ("dblib:host=$this->host:$this->port;dbname=$this->dbname", "$this->username", "$this->pwd");
            //$this->db=new PDO ( "dblib:dbname = $this->dbname; host=$this->host;", $this->username, $this->pwd);
            //$this->db = new PDO('odbc:Driver={SQL Server};Server=host;Database=dbname; Uid=username;Pwd=pwd');
           
            //$connectionInfo = array( "Database"=>"dbname", "UID"=>"username", "PWD"=>"password");
            //$conn = sqlsrv_connect( $this->host, $connectionInfo);

			$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
        }
		catch(PDOException $exception)
		{
            echo "Connection error: " . $exception->getMessage();
        }
         
        return $this->conn;
    }
}
?>