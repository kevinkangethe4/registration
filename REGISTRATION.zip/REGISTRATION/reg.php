<?php

?>
<doctype html>
<html>
<title>Registration Form</title>
<script> 
function validate()                                    
{ 

    var email = document.forms["RegForm"]["email"];               

    var password = document.forms["RegForm"]["password"]; 
	var password = document.forms["RegForm"]["repassword"];    


    var idnumber = document.forms["RegForm"]["idnumber"];  

    var firstname =  document.forms["RegForm"]["firstname"];  

    var lastname = document.forms["RegForm"]["lastname"];  

    var phone = document.forms["RegForm"]["phone"]; 
	var resident = document.forms["RegForm"]["resident"];
    var dateofbirth= document.forms["RegForm"]["dateofbirth"];
    var gender = document.forms["RegForm"]["gender"];

    if (email.value == "")                                  

    { 

        window.alert("Please enter your e-mail."); 

        name.focus(); 

        return false; 

    } 

    if (email.value.indexOf("@", 0) < 0)                 

    { 

        window.alert("Please enter a valid e-mail address."); 

        email.focus(); 

        return false; 

    } 

   

    if (email.value.indexOf(".", 0) < 0)                 

    { 

        window.alert("Please enter a valid e-mail address."); 

        email.focus(); 

        return false; 

    } 

    if (password.value == "")                               

    { 

        window.alert("Please enter your Password."); 

        name.focus(); 

        return false; 

    } 
	 var password=document.RegForm.password.value

    if (password.length <6)                               

    { 

        window.alert("Password must be at least 6 character long");  

        return false; 

    } 
	var password=document.RegForm.password.value;
    var repassword=document.RegForm.repassword.value;

       if (password == repassword)                               

    {
		return true;
	}
	
	else{
		

       window.alert("password not matching!!!");  

        return false; 

    } 

    if (firstname.value == "")                                   

    { 

        window.alert("Please enter a valid firstname address."); 

        email.focus(); 

        return false; 

    } 

   

   

   

    if (lastname.value == "")                           

    { 

        window.alert("Please enter your lastname."); 

        phone.focus(); 

        return false; 

    } 

   

    if (phone.value == "")                        

    { 

        window.alert("Please enter your phone"); 

        password.focus(); 

        return false; 

    } 

    if (resident.value == "")                        

    { 

        window.alert("Please enter your resident"); 

        password.focus(); 

        return false; 

    } 
 if (dateofbirth.value == "")                        

    { 

        window.alert("Please enter your date of birth"); 

        password.focus(); 

        return false; 

    } 
    if (gender.selectedIndex < 1)                  

    { 

        alert("Please enter your gender."); 

        what.focus(); 

        return false; 

    } 

   

    return true; 
}
</script> 
<style>
body{background-image:url(k2.jpg);background-size:tile;}
h1{color:red;background-color:black;border-style:ridge;border-color:red;font-type:tahoma;font-family:bold;font-size:30px;text-align:left;}
h2{font-type:tahoma;font-family:bold;font-size:15px;text-align:left;color:blue;}
p{background-color:pupple;font-type:tahoma;font-family:bold;font-size:20px;padding:30px,40px;}
a:link,.vistited{color:red; background-color:red; font-size:20px;width:30%;margin:8px;border:1px solid;padding:12px 20px;}
input[type=text],select{background-color:black;color:red;font-family:bold;font-size:20px;width:60%;padding:10px 30px;margin:10px 0;border:1px solid;border-color:black;border-radius:4px; box-sizing:border-box;display:inline-block;border-bottom:2px solid RED;}
input[type=submit],select{width:30%;padding:12px 20px;margin:8px;border:1px solid;border-color:white; color:blue;background-color:red;}
input[type=submit]:hover{background-color:red;}
input[type=password],select{background-color:black;color:red;font-family:bold;font-size:20px;width:60%;padding:10px 30px;margin:10px 0;border:1px solid;border-color:black;border-radius:4px; box-sizing:border-box;display:inline-block;border-bottom:2px solid green;}
input[type=radio],select{color:red;font-family:bold;font-size:20px;width:5%;padding:2px 3px;margin:4px 0;border:1px solid;border-color:white;border-radius:4px; box-sizing:border-box;display:inline-block;border-bottom:2px solid green;}.login-box{width:280px;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)};ut[type=date],select{color:red;font-family:bold;font-size:20px;width:60%;padding:10px 30px;margin:10px 0;border:1px solid;border-color:white;border-radius:4px; box-sizing:border-box;display:inline-block;border-bottom:2px solid green;}
.login-box{width:600px;position:absolute;top:100%;left:50%;transform:translate(-50%,-50%);background-color:black;}
input[type=date],select{background-color:black;color:red;font-family:bold;font-size:20px;width:60%;padding:10px 30px;margin:10px 0;border:1px solid;border-color:black;border-radius:4px; box-sizing:border-box;display:inline-block;border-bottom:2px solid WHITE;}
input[type=email],select{background-color:black;color:red;font-family:bold;font-size:20px;width:60%;padding:10px 30px;margin:10px 0;border:1px solid;border-color:black;border-radius:4px; box-sizing:border-box;display:inline-block;border-bottom:2px solid WHITE;}
} 
</style>
<body>
<div class="login-box">
<h1 style=text-align:center;>Registration Form</h1>
<form name="RegForm" action="insert.php" method="POST"action="/submit.php" onsubmit="return validate() " >
<table width="1000" height="15">
<tr>
<td><h2><input type="email" placeholder="Email" id="email" name="email"><p></p></h2></td></tr>
<td><h2><input type="password" placeholder="Password" id="password" name="password"><p></p></h2></td></tr>
<tr><td><h2><input type="password" placeholder="Re-type Password" id="repassword" name="repassword"><p></p></h2></td>
  
</tr>
<td><h2><input type="text" placeholder="Id Number"  id="idnumber" name="idnumber"><p></p></h2></td></tr>
<tr>
<td><h2><input type="text" placeholder="First Name" id="firstname" name="firstname"><p></p></h2></td></tr>
<td><h2><input type="text" placeholder="Last Name" id="lastname" name="lastname"><p></p></h2></td>
</tr>
<tr>
<td><h2><input type="text" placeholder="Phone Number"  id="phone" name="phone"><p></p></h2></td></tr>
<tr>
<td><h2><input type="text" placeholder="Resident" id="resident" name="resident"><p></p></h2></td>
</tr>
<td><H2>Date of Birth</H2><td><tr>
<td><h2 ><input type="date" placeholder="Date Of Birth" id="dateofbirth" name="dateofbirth"><p></p></h2></td>
</tr>
<tr>
<td><h2 style=text-align:left;color:red;>Gender</h2></td><tr/>
<tr>
<td><h2 style=text-align:left;><input type="radio" name="gender" value="Male">Male</h2></td><tr>
<td><h2 style=text-align:left; ><input type="radio" name="gender" value="Female">Female</h2></td>
</tr>
<tr>
<td><h2><input type="submit" value="Submit"></h2></td>
</tr>
<tr>
<td><h2>After Submit <a href="login.php"> Login</a>here to continue.</h2></td>
</table>

</form>
<h2 style=text-align:center;color:green;>"Karibu Sana"</h2>
</div>

</body>
</html>