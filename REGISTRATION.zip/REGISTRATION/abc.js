<script>
function validateform(){
	var firstname=document.myform.firstname.value;
	var password=document.myform.password.value;
	if(firstname=null || firstname==""){
		alert("name cant be blank");
		return false;
	}else if (password.length<6){
		alert("password must be 6 character long");
		return false;
	}
}</script>